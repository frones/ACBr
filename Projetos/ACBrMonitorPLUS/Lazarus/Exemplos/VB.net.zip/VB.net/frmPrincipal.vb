﻿Imports System
Imports System.Text
Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports Microsoft.VisualBasic
Public Class frmPrincipal

    Public tcpClient As New System.Net.Sockets.TcpClient()

    Public Function TCP()
        txtLog.Text &= "Estabelecendo conexão." & vbNewLine

        Dim networkStream As NetworkStream = tcpClient.GetStream()

        If networkStream.CanWrite And networkStream.CanRead Then
            ' executa apenas uma escrita
            Dim sendBytes As Byte() = Encoding.ASCII.GetBytes("NFE.StatusServico()" & Chr(13) & Chr(10) & "." & Chr(13) & Chr(10)) ' <---------------- string que quero enviar
            networkStream.Write(sendBytes, 0, sendBytes.Length)
            ' Le o NetworkStream em um buffer
            Dim bytes(tcpClient.ReceiveBufferSize) As Byte
            networkStream.Read(bytes, 0, CInt(tcpClient.ReceiveBufferSize))
            ' exibe os dados recebidos do host no console
            Dim returndata As String = Encoding.ASCII.GetString(bytes)
            txtLog.Text &= vbNewLine & "ACBr Monitor retornou: " + returndata & vbNewLine
        Else
            If Not networkStream.CanRead Then
                Console.WriteLine("Não é possível enviar dados para este stream")
                tcpClient.Close()
            Else
                If Not networkStream.CanWrite Then
                    Console.WriteLine("Não é possivel ler dados deste stream")
                    tcpClient.Close()
                End If
            End If
        End If
    End Function
    Private Sub frmPrincipal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtLog.Text &= "Estabelecendo conexão." & vbNewLine
        tcpClient.Connect("localhost", 3434)
    End Sub
    Private Sub btnConectar_Click(sender As Object, e As EventArgs) Handles btnConectar.Click
        TCP()
    End Sub

    Private Sub btnEnviar_Click(sender As Object, e As EventArgs) Handles btnEnviar.Click
        txtLog.Clear()

        Dim networkStream As NetworkStream = tcpClient.GetStream()

        Dim sendBytes As Byte() = Encoding.ASCII.GetBytes(txtC.Text & Chr(13) & Chr(10) & "." & Chr(13) & Chr(10)) ' <---------------- string que quero enviar
        networkStream.Write(sendBytes, 0, sendBytes.Length)

        Dim bytes(tcpClient.ReceiveBufferSize) As Byte
        networkStream.Read(bytes, 0, CInt(tcpClient.ReceiveBufferSize))
        Dim returndata As String = Encoding.ASCII.GetString(bytes)
        txtLog.Text &= vbNewLine & "ACBr Monitor retornou: " + returndata & vbNewLine

    End Sub
End Class
