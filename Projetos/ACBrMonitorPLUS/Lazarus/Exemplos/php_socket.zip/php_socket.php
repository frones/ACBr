<?php
require_once($_SERVER['DOCUMENT_ROOT']."/../WEB-INF/webconfig.inc.php");

try {
    $sc = new ClientSocket();
    $sc->open("127.0.0.1",3434);
    $response = $sc->recv();
    $sc->send("ECF.Ativo\n");
        $sc->send("ECF.Ativar\n");
        $sc->send("ECF.TestaPodeAbrirCupom\n");
    $resposta = $sc->recv();
        echo nl2br($resposta)."<br>";
        if (strpos($resposta, 'Redu��o Z')) {
                echo "GERANDO REDUCAO Z: ";
                $sc->send("ECF.ReducaoZ('".date('d/m/Y h:i:s')."')\n");
            $resposta = $sc->recv();
                echo nl2br($resposta);
        } else {
                $sc->send("ECF.AbreCupom('{$_POST['cnpj_cpf']}')\n");
            $resposta = $sc->recv();
                for ($i = 0; $i < count($_POST['produto']); $i++) {
                        $sc->send("ECF.VendeItem(\"{$_POST['cod'][$i]}\",\"{$_POST['produto'][$i]}\",\"18\",{$_POST['peso'][$i]}, 10.34, 0,\"KG\")\n");
                        $resposta = $sc->recv();
                }
                $sc->send("ECF.SubtotalizaCupom\n");
                $resposta = $sc->recv();
                echo "ECF.SubtotalizaCupom: $resposta<br>";
                $sc->send("ECF.EfetuaPagamento(\"01\", {$_POST['total_pago']})\n");
                $resposta = $sc->recv();
                echo "ECF.EfetuaPagamento: $resposta<br>";
                $sc->send("ECF.FechaCupom(\"Cupom Finalizado|nononononono\")\n");
                $resposta = $sc->recv();
                echo "ECF.FechaCupom: $resposta<br>";
        }
}catch (Exception $e){
    echo $e->getMessage();
}
